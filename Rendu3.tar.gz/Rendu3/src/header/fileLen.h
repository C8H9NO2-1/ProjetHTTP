#ifndef FILELEN_H
#define FILELEN_H

long int calulContenLen(FILE *file);

#endif
