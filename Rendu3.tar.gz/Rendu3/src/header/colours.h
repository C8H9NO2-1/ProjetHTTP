/*
 * Ce fichier est inutile autre que pour ajouter de la couleur dans la sortie
 */

#ifndef COLOURS_H
#define COLOURS_H

void black();
void red();
void green();
void yellow();
void blue();
void purple();
void cyan();
void reset();

#endif
