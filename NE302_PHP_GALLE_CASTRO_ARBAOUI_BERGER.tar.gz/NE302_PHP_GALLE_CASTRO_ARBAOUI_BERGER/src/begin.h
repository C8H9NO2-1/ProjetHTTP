#ifndef BEGIN_H
#define BEGIN_H

FCGI_BeginRequestBody beginRequest();

#endif