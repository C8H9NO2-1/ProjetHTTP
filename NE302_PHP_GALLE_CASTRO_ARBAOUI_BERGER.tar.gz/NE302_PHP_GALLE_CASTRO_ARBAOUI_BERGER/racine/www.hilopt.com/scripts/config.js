/*********************************************************************************
 * 
 * Ce fichier contient toutes les constantes nécessaires au fonctionnement du jeu.
 * En particulier les listes de mots et de phrases proposés à l'utilisateur
 * 
 *********************************************************************************/

// Déclaration des tableaux contenant les listes des mots proposés à l'utilisateur
const listeMots = ["Informatique", "Réseau", "Cybersécurité"]
const listePhrases = ["Vous êtes en train de tester un serveur HTTP", "Il nous reste encore tellement de choses à faire", "Merci pour le test"]
