## To Do

- Pour les differents fichiers
    > Liste des types de fichiers presents sur notre architecture
    * [ ] image/png
    * [ ] image/jpeg
    * [ ] text/html
    * [ ] text/css
    * [ ] text/javascript
    * [ ] image/gif
- Ajouter le support pour une requete de type Post

## Doing

- Generer la reponse
    * [x] Lister tous les codes possibles
    * [ ] Lister tous les headers avec leurs valeurs
    * [ ] Les mettre dans une structure qui nous aidera pour generer la reponse
    * [ ] Faire une fonction qui genere la reponse
- Faire un sample de requete a envoyer au serveur

## Done

- Gestion de la connection
    > Cela ne devrait pas etre trop complique avec la bibliotheque de Giorgi
- Implementation du header Connection
    > Enlever la dependance a la casse
- Normaliser la request-target
    * [x] Normaliser la casse
    * [x] Normaliser le %..
    * [x] Normaliser les /. et /..
- Mettre les options de connexion insensibles a la casse
- Accepter tous les sous-versions d'HTTP
- Voir les autres headers
    * [x] Referer
    * [x] User-Agent
    * [x] Accept
    * [x] Accept-Encoding
- Implementer une "interface" pour la gestion des headers de la requete
