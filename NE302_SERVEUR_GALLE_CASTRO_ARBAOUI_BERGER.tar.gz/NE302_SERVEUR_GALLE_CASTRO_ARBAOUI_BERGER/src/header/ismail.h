#ifndef IS_H
#define IS_H


bool semanticContentLength(void *root);
// bool semanticContentType(void * root);
#endif